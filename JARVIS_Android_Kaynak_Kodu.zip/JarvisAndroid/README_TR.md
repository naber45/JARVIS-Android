# JARVIS Android — başlangıç projesi

Bu paket, Redmi Note 13 / Android için **ilk prototip kaynak kodudur**. Henüz bitmiş, imzalanmış APK değildir.

## İçindekiler
- Türkçe konuşma tanıma (Android'in kurulu konuşma tanıma servisini kullanır)
- Android metin okuma (TTS; Türkçe ses ve kadın sesi seçimi cihazın TTS motoruna bağlıdır)
- Basit sesli komutlar: Wi-Fi paneli, Bluetooth ayarları, genel ayarlar, alarm ekranı, kamera, bazı uygulamalar, arama ekranı ve SMS taslağı
- Erişilebilirlik servisi iskeleti

## Önemli sınırlar
- **“Hey Jarvis” sürekli uyandırma henüz ekli değil.** Bu prototipte kullanıcı mikrofon düğmesine basar. Gerçek sürekli uyandırma için ayrı bir wake-word motoru, mikrofon foreground service bildirimi, pil/üretici kısıtları ve ek testler gerekir.
- İnternetli büyük dil modeli bağlantısı henüz ekli değil. API anahtarını Android uygulamasına doğrudan gömmek güvenli değildir; bunun için güvenli bir sunucu ara katmanı gerekir.
- Erişilebilirlik servisi bu sürümde ekran içeriğini okumaz, tıklama yapmaz ve tuş kaydı tutmaz. Android erişilebilirlik izni güçlüdür; yalnızca açıkça gerekli ve kullanıcı tarafından başlatılan işler için genişletilmelidir.
- Wi-Fi/Bluetooth gibi bazı ayarlar Android tarafından doğrudan değiştirtilemez; uygulama ilgili sistem panelini açar.
- Arama ve SMS bu sürümde doğrudan gönderilmez; telefonun arama/mesaj ekranını açar ve son onayı kullanıcı verir.
- Çevrimdışı konuşma tanıma, cihazdaki tanıma motorunun çevrimdışı dil paketine bağlıdır.

## Derleme
1. Bilgisayarda Android Studio kurun.
2. Bu klasörü Android Studio ile açın.
3. Gradle senkronizasyonunu tamamlayın.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seçin.
5. Oluşan APK'yı telefona aktarın ve yükleyin.
6. İlk açılışta mikrofon iznini verin. Erişilebilirlik ayarına yalnızca ileride gerekli bir özellik eklenirse girin.

## Sonraki geliştirme aşaması
1. Güvenli sunucu üzerinden yapay zekâ bağlantısı.
2. Açık kaynak veya lisanslı wake-word motoruyla “Hey Jarvis”.
3. Mikrofon foreground service ve görünür bildirim.
4. İzinli, denetlenebilir erişilebilirlik eylemleri.
5. Cihazda çevrimdışı komut motoru ve Türkçe ses seçenekleri.
