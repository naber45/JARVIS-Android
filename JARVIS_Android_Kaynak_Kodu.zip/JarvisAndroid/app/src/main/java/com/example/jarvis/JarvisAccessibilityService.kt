package com.example.jarvis

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * İlk sürümde yalnızca Android erişilebilirlik servisi bağlantısını sağlar.
 * Ekran içeriği toplamaz, tuş kaydı yapmaz ve otomatik tıklama yapmaz.
 * İleride eklenecek her eylem kullanıcı tarafından açıkça başlatılmalıdır.
 */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Bilerek veri toplamıyoruz.
    }

    override fun onInterrupt() = Unit
}
