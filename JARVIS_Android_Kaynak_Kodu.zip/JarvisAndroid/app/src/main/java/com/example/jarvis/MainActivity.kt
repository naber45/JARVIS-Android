package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
            setBackgroundColor(0xFF08111F.toInt())
        }
        status = TextView(this).apply {
            text = "J.A.R.V.I.S.  •  ÇEVRİMİÇİ / ÇEVRİMDIŞI TEMEL SÜRÜM"
            textSize = 20f
            setTextColor(0xFF63D9FF.toInt())
        }
        transcript = TextView(this).apply {
            text = "Hazırım efendim. Mikrofon düğmesine basarak konuşabilirsiniz."
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 40, 0, 40)
        }
        val listen = Button(this).apply {
            text = "🎙 JARVIS'İ DİNLE"
            setOnClickListener { startListening() }
        }
        val accessibility = Button(this).apply {
            text = "Erişilebilirlik ayarlarını aç"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val micSettings = Button(this).apply {
            text = "Mikrofon iznini ver"
            setOnClickListener { requestMicPermission() }
        }
        layout.addView(status)
        layout.addView(transcript)
        layout.addView(listen)
        layout.addView(micSettings)
        layout.addView(accessibility)
        setContentView(layout)
        requestMicPermission()
    }

    private fun requestMicPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Bu telefonda kullanılabilir konuşma tanıma hizmeti bulunamadı, efendim.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestMicPermission()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Sizi dinliyorum..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Komut işleniyor..." }
            override fun onError(error: Int) {
                status.text = "Dinleme tamamlanamadı. Tekrar deneyin."
            }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                transcript.text = "Siz: $phrase"
                handleCommand(phrase.lowercase(Locale("tr", "TR")))
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("saat") -> say("Saat bilgisi için telefonunuzun saatini kontrol edebilirsiniz, efendim.")
            command.contains("alarm") -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS hatırlatması")
                    putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                }
                safelyLaunch(i, "Alarm uygulamasını açıyorum, efendim.")
            }
            command.contains("wifi") || command.contains("wi-fi") ->
                safelyLaunch(Intent(Settings.Panel.ACTION_WIFI), "Wi-Fi panelini açıyorum, efendim.")
            command.contains("bluetooth") ->
                safelyLaunch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Bluetooth ayarlarını açıyorum, efendim.")
            command.contains("ayar") ->
                safelyLaunch(Intent(Settings.ACTION_SETTINGS), "Ayarları açıyorum, efendim.")
            command.startsWith("ara ") || command.startsWith("telefon et ") -> {
                val number = command.substringAfter(" ").replace(" ", "")
                safelyLaunch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")), "Arama ekranını açıyorum. Aramayı siz başlatabilirsiniz, efendim.")
            }
            command.startsWith("mesaj ") -> {
                val body = command.removePrefix("mesaj ")
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).apply {
                    putExtra("sms_body", body)
                }
                safelyLaunch(i, "Mesaj ekranını açıyorum. Göndermeden önce kontrol edebilirsiniz, efendim.")
            }
            command.contains("kamera") ->
                safelyLaunch(Intent("android.media.action.IMAGE_CAPTURE"), "Kamerayı açıyorum, efendim.")
            command.contains("youtube") -> openApp("com.google.android.youtube", "YouTube")
            command.contains("chrome") -> openApp("com.android.chrome", "Chrome")
            command.contains("hesap makinesi") -> openApp("com.google.android.calculator", "Hesap makinesi")
            command.contains("arama yap") || command.contains("internette ara") -> {
                val q = command.substringAfter("ara").trim()
                safelyLaunch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))), "İnternette arıyorum, efendim.")
            }
            else -> say("Komutu anladım demek için erken, efendim. Bu ilk sürümde bu komut henüz tanımlı değil.")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) safelyLaunch(launch, "$label uygulamasını açıyorum, efendim.")
        else say("$label telefonda bulunamadı, efendim.")
    }

    private fun safelyLaunch(intent: Intent, spoken: String) {
        try {
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
                say(spoken)
            } else say("Bu işlem için uygun bir uygulama bulunamadı, efendim.")
        } catch (_: Exception) {
            say("Bu işlemi başlatamadım, efendim.")
        }
    }

    private fun say(message: String) {
        transcript.text = message
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("tr", "TR"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            // Android cihazdaki Türkçe kadın sesi varsa sistem motoru seçebilir; ses seçimi cihaza bağlıdır.
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
